A LOT OF IMAGES, I know.
May cause slowdowns on the godot editor and long load times.

This is a bunch (+8000) of files, merged from the original +38000 files.
This is used by the S2AS tool, to convert old GML sprites to Godot Animated Sprites.

Its a mess, but im doing the best I can.